watch -b -c ss -tp
