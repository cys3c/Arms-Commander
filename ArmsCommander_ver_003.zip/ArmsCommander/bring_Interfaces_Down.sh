airmon-ng stop wlan1mon
airmon-ng stop wlan0mon
airmon-ng check kill
ifconfig wlan0 down
ifconfig wlan1 down
ifconfig eth0 down
