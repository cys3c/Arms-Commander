snort -q -A console -c /etc/snort/snort.conf
